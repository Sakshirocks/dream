<?php include "includes/config.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dream House</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900,400italic,700italic' rel='stylesheet' type='text/css'>

    

</head>

<body>

  <?php include "includes/header.php"; ?>

    <!-- Header Carousel -->
   <?php include "slider.php"; ?>

    <!-- Page Content -->
<?php
$query = mysql_query("select * from homecontent");
$row  = mysql_fetch_array($query);
?>
    <div class="container color-light">
        <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header site-font">
                    <?php echo $row['hc_title'];  ?>
                </h1>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <p class="intro"><?php echo htmlspecialchars_decode($row['hc_descp']); ?></p>
                        
                    </div>
                </div>
            </div>
            
            <div class="col-md-5 col-sm-12">
            	<img src="img/<?php echo $row['hc_feature_img']; ?>" class="img-responsive img-rounded"/>
            </div>
            
        </div>
        <!-- /.row -->

        <!-- Category Section -->
        <div class="row category-section">
            <div class="col-lg-12">
                <h2 class="page-header site-font">Categories</h2>
            </div>
            <?php
			$cquery = mysql_query("Select * from category");
			while($crow = mysql_fetch_array($cquery))
			{
			?>
            <div class="col-lg-3 col-md-4 col-sm-4 col-xm-6 nolpadd norpadd">
                <a href="category.php?cat=<?php echo $crow['cat_name']; ?>">
                    <img class="img-responsive img-portfolio" src="img/<?php echo $crow['cat_img']; ?>" alt="<?php echo $crow['cat_name']; ?>"/>
                    <div class="overlay"><h2><?php echo $crow['cat_name']; ?></h2></div>
                </a>
                
            </div>
            <?php } ?>
          
        </div>
        <!-- /.row -->

        <!-- Features Section >
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header site-font">RK Stones Features</h2>
            </div>
            <div class="col-md-6">
                <p>The RK Stones includes:</p>
                <ul>
                    <li>jQuery v1.11.0</li>
                    <li>Font Awesome v4.1.0</li>
                    <li>Working PHP contact form with validation</li>
                    <li>Unstyled page elements for easy customization</li>
                    <li>17 HTML pages</li>
                </ul>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, omnis doloremque non cum id reprehenderit, quisquam totam aspernatur tempora minima unde aliquid ea culpa sunt. Reiciendis quia dolorum ducimus unde.</p>
            </div>
            <div class="col-md-6">
                <img class="img-responsive" src="http://placehold.it/700x450" alt="">
            </div>
        </div>
        <!-- /.row -->

</div>

        <?php include "includes/footer.php"; ?>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

	<script src="js/main.js"></script>
    <!-- Script to Activate the Carousel -->
    <script>
    $('.carousel').carousel({
        interval: 3000 //changes the speed
    })
    </script>

</body>

</html>
