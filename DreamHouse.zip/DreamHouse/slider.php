<?php include "includes/config.php"; ?>
<header id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators-->
        
        <ol class="carousel-indicators">
        <?php
		$i=0;
		$sql= mysql_query("select * from homeslider");
		while($ff = mysql_fetch_array($sql))
		{
		?>
            <li data-target="#myCarousel" id="indicator<?php echo $ff['hs_id']; ?>" data-slide-to="<?php echo $i++; ?>"></li>
            
        <?php } ?>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
        
            
            <?php
			$query = mysql_query("select * from homeslider");
			while($row = mysql_fetch_array($query))
			{
			 ?>
            <div class="item">
                <img src="img/<?php echo $row['hs_img']; ?>" alt="<?php echo $row['hs_alt']; ?>" class="img-responsive" width="100%"/>
                <div class="carousel-caption">
                    <h2><?php echo $row['hs_alt']; ?></h2>
                </div>
            </div>
            <?php } ?>
            
        </div>

        <!-- Controls-->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </header>