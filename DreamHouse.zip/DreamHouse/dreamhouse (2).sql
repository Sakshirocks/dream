-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2016 at 05:50 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dreamhouse`
--
CREATE DATABASE IF NOT EXISTS `dreamhouse` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dreamhouse`;

-- --------------------------------------------------------

--
-- Table structure for table `aboutcontent`
--

CREATE TABLE IF NOT EXISTS `aboutcontent` (
  `ac_id` int(20) NOT NULL AUTO_INCREMENT,
  `ac_title` varchar(90) NOT NULL,
  `ac_descp` varchar(40000) NOT NULL,
  `ac_fimg` varchar(4000) NOT NULL,
  PRIMARY KEY (`ac_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `aboutcontent`
--

INSERT INTO `aboutcontent` (`ac_id`, `ac_title`, `ac_descp`, `ac_fimg`) VALUES
(1, 'About Us', '&lt;p class=&quot;MsoNormal&quot;&gt;\r\nAs the saying goes "the top three things to look for in properties are location, location and location" Rangoli Gardens qualifies on all three counts!  Phase 1 residents are already making the most of the 15000 sq ft Club House with all modern facilities, as well as enjoying the sheer beauty of the 8.8 acres of park area in the 26-acre project. From essential conveniences like power back up, regular water supply, piped gas etc to lifestyle enhancing features like a Community Hall, walking tracks and multiple sports facilities including a Tennis Court, Dream House is your dream home come true.\r\n\r\nLuxuriate in the vast open spaces of this 26-acrecomplex with 8.8 acres of area for a park\r\nMultiple options: 2 ,3 & 4 BHK apartments in either  G+4 or  Stilt+12 floors, both with lifts\r\nHassle-free designated parking areas for each apartment\r\nAdded reassurance in the form of  secure, single gated entry with intercom facility\r\nPlenty of activities to keep the whole family entertained:swimming pool, pool table, table tennis, gym, tennis, badminton, community hall and reading lounge\r\n750-watt power backup and regular water supply enhances the comfort quotient\r\nProvision for DTH and piped cooking-gas too\r\nEnvironmentally sound installations: Half-flush nubs, CFLs in common areas and solar panels. .&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&amp;nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&amp;nbsp;&lt;/p&gt;', 'front.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `aboutteam`
--

CREATE TABLE IF NOT EXISTS `aboutteam` (
  `tm_id` int(90) NOT NULL AUTO_INCREMENT,
  `tm_name` varchar(1000) NOT NULL,
  `tm_img` varchar(4000) NOT NULL,
  `tm_position` varchar(4000) NOT NULL,
  PRIMARY KEY (`tm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `aboutteam`
--

INSERT INTO `aboutteam` (`tm_id`, `tm_name`, `tm_img`, `tm_position`) VALUES
(2, 'Payal Khandelwal', 'payal.jpg', 'Team Leader'),
(3, 'sakshi', 'sakshi.jpg', 'Designer'),
(4, 'Prakriti Sharma', 'prakriti.jpg', 'Contractor');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(90) NOT NULL,
  `password` varchar(90) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin1235');

-- --------------------------------------------------------

--
-- Table structure for table `background`
--

CREATE TABLE IF NOT EXISTS `background` (
  `color_id` int(20) NOT NULL AUTO_INCREMENT,
  `color_code` varchar(10000) NOT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `background`
--

INSERT INTO `background` (`color_id`, `color_code`) VALUES
(1, '#af4149');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(90) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(1000) NOT NULL,
  `cat_img` varchar(4000) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_img`) VALUES
(1, 'Studio', 'studio-apartment.jpg'),
(2, 'Duplex', 'customer4.jpg'),
(3, 'Castle', 'castle.jpg'),
(4, 'Modern', 'modern.jpg'),
(5, 'Sapphire', 'hqdefault.jpg'),
(6, 'Traditional', 'customer6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(1000) NOT NULL,
  `phone` varchar(90) NOT NULL,
  `email` varchar(90) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `address`, `phone`, `email`) VALUES
(1, 'SKIT, Jaipur', '+91-8426010420', 'khandelwalpayal04@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contactform`
--

CREATE TABLE IF NOT EXISTS `contactform` (
  `form_id` int(90) NOT NULL AUTO_INCREMENT,
  `form_to` varchar(1000) NOT NULL,
  `form_subj` varchar(1000) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contactform`
--

INSERT INTO `contactform` (`form_id`, `form_to`, `form_subj`) VALUES
(1, 'khandelwalpayal04@gmail.com', 'Enquiry');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `cust_id` int(90) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(1000) NOT NULL,
  `cust_img` varchar(4000) NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `cust_name`, `cust_img`) VALUES
(1, 'Customer 1', 'castle.jpg'),
(2, 'Customer 2', 'house1.jpg'),
(3, 'Customer 3', 'customer3.jpg'),
(4, 'Customer4', 'customer4.jpg'),
(5, 'Customer 5', 'customer5.jpg'),
(6, 'Customer 6', 'customer6.jpg'),
(7, 'Customer 7', 'w1024.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `detailed_cat`
--

CREATE TABLE IF NOT EXISTS `detailed_cat` (
  `dcat_id` int(40) NOT NULL AUTO_INCREMENT,
  `dcat_name` varchar(4000) NOT NULL,
  `dcat_img1` varchar(4000) NOT NULL,
  `dcat_img2` varchar(4000) NOT NULL,
  `dcat_img3` varchar(4000) NOT NULL,
  `dcat_descp` varchar(4000) NOT NULL,
  PRIMARY KEY (`dcat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `detailed_cat`
--

INSERT INTO `detailed_cat` (`dcat_id`, `dcat_name`, `dcat_img1`, `dcat_img2`, `dcat_img3`, `dcat_descp`) VALUES
(5, 'Traditional', 't1.jpg', 't2.jpg', 't3.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Indian vernacular architecture the informal, functional architecture of structures, often in rural areas of India, built of local materials and designed to meet the needs of the local people. The builders of these structures are unschooled informal architectural design and their work reflects the rich diversity of India''s climate, locally available building materials, and the intricate variations in local social customs and craftsmanship. It has been estimated that worldwide close to 90% of all building is vernacular, meaning that it is for daily use for ordinary, local people and built by local craftsmen.The term "vernacular architecture" in general refers to the informal building of structures through traditional building methods by local builders without using the services of a professional architect. It is the most widespread form of building.&lt;/p&gt;'),
(6, 'Studio', 's1.jpg', 's2.jpg', 's3.jpg', '&lt;p &quot;&gt;A studio apartment also known as studio flat or bachelor type apartments is a small apartment which combines a living room,bedroom and kitchen all in a single room. Studio, efficiency, and bachelor style apartments all tend to be the smallest apartments with the lowest rents in a given area, usually ranging around 300 to 450 square feet.These kinds of apartments typically consist of one large room which serves as the living, dining, and bedroom. Kitchen facilities may either be located in the central room, or in a small separate room, and the bathroom is usually in its own smaller room. '),
(7, 'Sapphire', 'sp1.jpg', 'sp2.jpg', 'sp3.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc ac magna. Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis. Pellentesque porttitor, velit lacinia egestas auctor, diam eros tempus arcu, nec vulputate augue magna vel risus. Cras non magna vel ante adipiscing rhoncus. Vivamus a mi. Morbi neque. Aliquam erat volutpat. Integer ultrices lobortis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin semper, ante vitae sollicitudin posuere, metus quam iaculis nibh, vitae scelerisque nunc massa eget pede. Sed velit urna, interdum vel, ultricies vel, faucibus at, quam.&lt;/p&gt;'),
(8, 'Duplex', 'd1.jpeg', 'd2.jpg', 'd3.jpg', 'a duplex house is a dwelling having apartments with separate entrances for two households. This includes two-story houses having a complete apartment on each floor and also side-by-side apartments on a single lot that share a common wall.By contrast, a building comprising two attached units on two distinct properties is typically considered semi-detached or twin homes but may also be referred to as a duplex.\r\nThe term "duplex" can''t be extended to three-unit and four-unit buildings, as they would be referred to with specific terms such as triplex and fourplex or quadplex/quadruplex. Because of the flexibility of the term, the line between an apartment building and a duplex is somewhat blurred, with apartment buildings tending to be bigger, while duplexes are usually the size of a normal house.\r\nBritish English usage refers simply to the number of levels within an apartment unit with duplex indicating two storeys (traditionally this was referred to as a maisonette) and triplex for three. A semi-detached house would never be referred to as ''duplex''.'),
(9, 'Castle', 'c1.jpg', 'c2.jpg', 'c3.jpg', '&lt;p style=&quot;margin: 0.5em 0px; line-height: 22.4px; color: #252525; font-family: sans-serif; font-size: 14px;&quot;&gt;A&amp;nbsp;&lt;strong&gt;castle&lt;/strong&gt;&amp;nbsp;is a type of&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Fortification&quot; href=&quot;https://en.wikipedia.org/wiki/Fortification&quot;&gt;fortified&lt;/a&gt;&amp;nbsp;structure built in&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Europe&quot; href=&quot;https://en.wikipedia.org/wiki/Europe&quot;&gt;Europe&lt;/a&gt;&amp;nbsp;and the&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Middle East&quot; href=&quot;https://en.wikipedia.org/wiki/Middle_East&quot;&gt;Middle East&lt;/a&gt;&amp;nbsp;during the&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Middle Ages&quot; href=&quot;https://en.wikipedia.org/wiki/Middle_Ages&quot;&gt;Middle Ages&lt;/a&gt;&amp;nbsp;by&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Nobility&quot; href=&quot;https://en.wikipedia.org/wiki/Nobility&quot;&gt;nobility&lt;/a&gt;. Scholars debate the scope of the word&amp;nbsp;&lt;em&gt;castle&lt;/em&gt;, but usually consider it to be the private fortified residence of a lord or noble. This is distinct from a&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Palace&quot; href=&quot;https://en.wikipedia.org/wiki/Palace&quot;&gt;palace&lt;/a&gt;, which is not fortified; from a fortress, which was not always a residence for&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Nobility&quot; href=&quot;https://en.wikipedia.org/wiki/Nobility&quot;&gt;nobility&lt;/a&gt;; and from a fortified settlement, which was a public defence&amp;nbsp;&amp;ndash; though there are many similarities among these types of construction. Usage of the term has varied over time and has been applied to structures as diverse as&amp;nbsp;&lt;a class=&quot;mw-redirect&quot; style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Hill fort&quot; href=&quot;https://en.wikipedia.org/wiki/Hill_fort&quot;&gt;hill forts&lt;/a&gt;&amp;nbsp;and country houses. Over the approximately 900&amp;nbsp;years that castles were built, they took on a great many forms with many different features, although some, such as&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Curtain wall (fortification)&quot; href=&quot;https://en.wikipedia.org/wiki/Curtain_wall_(fortification)&quot;&gt;curtain walls&lt;/a&gt;&amp;nbsp;and&amp;nbsp;&lt;a style=&quot;text-decoration: none; color: #0b0080; background: none;&quot; title=&quot;Arrowslit&quot; href=&quot;https://en.wikipedia.org/wiki/Arrowslit&quot;&gt;arrowslits&lt;/a&gt;, were commonplace.&lt;/p&gt;\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;'),
(10, 'Modern', 'm1.jpg', 'm2.jpg', 'm3.jpg', 'Modern Architecture became linked to a certain genre of building and thus over time wasn''t really modern anymore. Thus Modern Houses (or Modernist Houses) suggests a certain style, not simply a contemporary or current construction.Modern Architecture was associated with some great architects and some powerful countries and companies. It became the equivalent of the Classical Style in the Georgian period, ie the establishment architecture, the status quo. Since the seventies architecture styles have become more fractured and we have amongst what could be termed contemporary architects ,post modernists, neo-modernists, deconstructivists, contextualists, expressionists and so on.');

-- --------------------------------------------------------

--
-- Table structure for table `homecontent`
--

CREATE TABLE IF NOT EXISTS `homecontent` (
  `hc_id` int(20) NOT NULL AUTO_INCREMENT,
  `hc_title` varchar(1000) NOT NULL,
  `hc_descp` text NOT NULL,
  `hc_feature_img` varchar(4000) NOT NULL,
  PRIMARY KEY (`hc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `homecontent`
--

INSERT INTO `homecontent` (`hc_id`, `hc_title`, `hc_descp`, `hc_feature_img`) VALUES
(1, 'Welcome to Dream House', '&lt;p class=&quot;MsoNormal&quot;&gt;\r\nSimplicity is beauty. That is what people usually say about many things. But,simplicity is not enough when it comes about your dream house. Your dream house should still be simple, but in another manner. It should not be simple that it would be made out of wood, but it should be simple in a way that it has simple designs, yet it should be appealing in the eyes.\r\n&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;\r\nYour Dream House should be your reflection. When you look at this home, it would be almost as if you were looking into your soul. Every corner of this house will show your personality and in some cases will even show your inner self..&lt;/p&gt;', 'front.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `homeslider`
--

CREATE TABLE IF NOT EXISTS `homeslider` (
  `hs_id` int(90) NOT NULL AUTO_INCREMENT,
  `hs_alt` varchar(1000) NOT NULL,
  `hs_img` varchar(4000) NOT NULL,
  PRIMARY KEY (`hs_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `homeslider`
--

INSERT INTO `homeslider` (`hs_id`, `hs_alt`, `hs_img`) VALUES
(3, 'Image 3', 'bannerimg3.jpg'),
(4, 'Image 1', 'img3.jpg'),
(5, 'Image 4', 'img1.jpg'),
(6, '12', 'img2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `image_gallery`
--

CREATE TABLE IF NOT EXISTS `image_gallery` (
  `gallery_id` int(90) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(1000) NOT NULL,
  `gallery_title` varchar(1000) NOT NULL,
  `gallery_feature_img` varchar(4000) NOT NULL,
  `gallery_img_desc` varchar(40000) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`gallery_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `image_gallery`
--

INSERT INTO `image_gallery` (`gallery_id`, `cat_name`, `gallery_title`, `gallery_feature_img`, `gallery_img_desc`, `add_date`) VALUES
(7, 'Studio', 'Studio', 'studio-apartment.jpg', '&lt;p&gt;Studio Apartment with all basic amenities and modern finish up with modular kitchen and wooden furniture,small place with a whole world.&lt;/p&gt;', '2015-09-19 06:00:07'),
(8, 'Castle', 'Castle', 'castle.jpg', '&lt;p&gt;There resides a prince and princess in everyone and what if you actually get a chance to live in your very own palace.So here we come with our very own disneyland.&lt;/p&gt;', '2015-09-19 06:02:00'),
(9, 'Duplex', 'Duplex', 'customer4.jpg', '&lt;p&gt;This is a duplex house Plan having 1 Bedroom, kitchen, dining drawing, 2 toilet and 2 car parking at ground floor. At first floor it has 2 bedrooms, 2 toilet and living area with balcony.&lt;/p&gt;', '2015-09-19 06:03:09'),
(10, 'Traditional', 'Traditional', 'customer6.jpg', '&lt;p&gt;The Hindu temple architecture is an open, symmetry driven structure, with many variations, on a square grid of padas, deploying perfect geometric shapes such as circles and squares.A Hindu temple consists of an inner sanctum, the garbha griha or womb-chamber, where the primary idol or deity is housed along with Purusa. The garbhagriha is crowned by a tower-like Shikhara, also called the Vimana. The architecture includes an ambulatory for parikrama (circumambulation), a congregation hall, and sometimes an antechamber and porch.&lt;/p&gt;', '2015-09-19 06:03:30'),
(11, 'Duplex', 'Duplex', 'customer5.jpg', '&lt;p&gt;House with a perfect location for your perfect small family. it caters to all your needs and gives you a pleasure of living in a villa with its unique design and facilities.&lt;/p&gt;', '2015-09-19 06:03:49'),
(12, 'Traditional', 'Traditional', 'customer3.jpg', '&lt;p&gt;The Hindu temple architecture reflects a synthesis of arts, the ideals of dharma, beliefs, values and the way of life cherished under Hinduism. It is a link between man, deities, and the Universal Purusa in a sacred space.Susan Lewandowski states that the underlying principle in a Hindu temple is built around the belief that all things are one, everything is connected. The pilgrim is welcomed through mathematically structured spaces, a network of art, pillars with carvings and statues that display and celebrate the four important and necessary principles of human life - the pursuit of artha (prosperity, wealth), the pursuit of kama (pleasure, sex), the pursuit of dharma (virtues, ethical life) and the pursuit of moksha (release, self-knowledge)&lt;/p&gt;', '2015-09-19 06:04:06'),
(13, 'Modern', 'Modern', 'modern.jpg', '&lt;p&gt;Modern house plans offer clean lines, simple proportions, open layouts and abundant natural light, and are descendants of the International style of architecture, which developed in the 1920s. Flat or shallow-pitched roofs, large expanses of glass, strong connections to outdoor space, and spare, unornamented walls are characteristics of Modern house plans. The lot is often incorporated into the Modern style home, turning outdoor space into alfresco living rooms.&lt;/p&gt;', '2015-09-19 06:05:52'),
(14, 'Sapphire', 'Sapphire', 'hqdefault.jpg', '&lt;p&gt;This Sapphire Beach property provides a number of possibilities for the astute buyer, making full use of the awesome uninterrupted ocean, island and beach views. You could make the most of the 1125m2 block by modernising the existing home, build a 2nd, additional dwelling on the vacant part of the block, or demolish everything and build totally new over the whole block. Plans are available for options 1 and 2. The home has a fully enclosed sunroom and living area with full height windows to make the most of the sensational views, while the bottom level can provide the option of self-contained accommodation for family or friends.&lt;/p&gt;', '2015-09-19 06:06:07');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
