<?php include "includes/config.php"; 
//error_reporting(0);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Dream House | Gallery</title>
<link rel="stylesheet" href="css/app.css">
<link rel="stylesheet" href="css/style.css"/>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/bootstrap-theme.css" type="text/css" rel="stylesheet" media="all">

<link rel="stylesheet" href="css/base.css">

	<link rel="stylesheet" href="css/layout.css">
	<link rel="stylesheet" href="css/colio.css">
	
	
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>

<?php include "includes/header.php"; ?>

<section class="mynewgallery">

<div class="container color-light">

<div class="row">

<div class="col-md-12">

				
			<div class="portfolio clearfix">
				
				<div class="filters">
                <a href="#" class="filter-active">All</a>
                <?php 
					$query = mysql_query("Select * from category");
					while($r = mysql_fetch_array($query))
					{
				?>
		<a href="#<?php echo $r['cat_name']; ?>"><?php echo ucfirst($r['cat_name']); ?></a>
					
                <?php } ?>
				</div><!-- filters -->
				
	<ul class="list clearfix">
					<?php
						$sql = mysql_query("Select * from image_gallery");
						while($row = mysql_fetch_array($sql))
						{
						?>
		<li class="<?php echo $row['cat_name']; ?>"  data-content="#colio_c1<?php echo $row['gallery_id']; ?>">
						<div class="thumb">
							<div class="view">
	<a class="button colio-link" href="#">View Project</a>
							</div>
							<img src="gallery-img/<?php echo $row['gallery_feature_img']; ?>" alt="<?php echo $row['cat_name']; ?>"/>
						</div>
						<h4><a class="colio-link" href="#"><?php echo $row['gallery_title']; ?></a></h4>
						<p><?php echo substr(htmlspecialchars_decode($row['gallery_img_desc']),0,40); ?></p>
					</li>
                   <?php } ?>
                   
                    	
					
				</ul><!-- list -->

			</div><!-- portfolio -->
				<?php 
            $qq = mysql_query("select * from image_gallery");
	while($rr = mysql_fetch_array($qq)){
		?>
			<div id="colio_c1<?php echo $rr['gallery_id']; ?>" class="colio-content">
			
				<div class="side">
		
				<div class="flexslider">
					<ul class="slides">
		   <li><img src="gallery-img/<?php echo $rr['gallery_feature_img']?>" 
           alt="<?php echo $rr['gallery_title']; ?> pic"/></li>
					</ul>
				</div>
				
				</div><!-- side -->
					
				<div class="main">
					
					<h3><?php echo $rr['gallery_title']; ?></h3>
					<p><?php echo htmlspecialchars_decode($rr['gallery_img_desc']); ?></p>
					<!--<a class="visit-link" href="#">Visit Site</a>-->
					
				</div><!-- main -->
								
			</div><!-- colio-content # colio_c1 -->
			
	<?php } ?>		
			
				
		
		<!-- SPACER --> <div class="spacer"></div>
		
</div>

</div>
</div>
</section>

<?php include "includes/footer.php"; ?>




<script src="js/jquery-2.1.0.min.js"></script>

<script src="js/bootstrap.js"></script>


<!--<script type="text/javascript" src="js/jquery.min.js"></script>-->
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.scrollUp.min.js"></script>
	<script type="text/javascript" src="js/jquery.browser.js"></script>
	<script type="text/javascript" src="js/jquery.quicksand.js"></script>
	<script type="text/javascript" src="js/jquery.colio.min.js"></script>
	
	
	<!-- Colio White Theme
	================================================== -->
	
	<link rel="stylesheet" href="css/flexslider.css">
	<script type="text/javascript" src="js/jquery.flexslider.js"></script>
	
	<script type="text/javascript">
		$(document).ready(function(){
			
			// "scrollTop" plugin
			$.scrollUp();
			
			// "colio" plugin
			var colio_run = function(){
				$('#demo_1').remove();
				$('.portfolio .list').colio({
					id: 'demo_1',
					theme: 'white',
					placement: 'before',
					onContent: function(content){
						// init "flexslider" plugin
						$('.flexslider', content).flexslider({slideshow: false, animationSpeed: 300});
					}
				});
			};
			
			colio_run();
						
			// "quicksand" plugin
			var quicksand_run = function(items){
				$('.portfolio .list').quicksand(items, {
					retainExisting: false, adjustWidth:false, duration: 500
				}, colio_run);
			};
			
			$('.portfolio .list li').each(function(n){
				$(this).attr('data-id', n);
			});
			
			var copy = $('.portfolio .list li').clone();
			
			$('.portfolio .filters a').click(function(){
				$(this).addClass('filter-active').siblings().removeClass('filter-active');
				var href = $(this).attr('href').substr(1);
				filter = href ? '.' + href : '*';
				quicksand_run(copy.filter(filter));
				return false;
			});
			
		});
	</script>












</body>
</html>


