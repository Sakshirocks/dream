<?php
include "includes/config.php";
$query = mysql_query("select * from contactform");
$r = mysql_fetch_array($query);
?>
<?php
$name = mysql_real_escape_string($_REQUEST['name']);
$phone = mysql_real_escape_string($_REQUEST['phone']);
$email = htmlspecialchars($_REQUEST['email']);
$msg = htmlspecialchars($_REQUEST['message']);
$captcha = $_REQUEST['captcha'];
$reenter = mysql_real_escape_string($_REQUEST['reenter']);
$mymail = $r['form_to'];
$subject = $r['form_subj'];
$message = "
Name : $name
Email : $email
Phone : $phone
Message : $msg";


if(empty($name) || empty($phone) || empty($email) || empty($msg) || empty($reenter))
{
	header("location:contact.php?error=Please fill all the fields#error");
	exit();
}
elseif($captcha != $reenter)
{
	header("location:contact.php?error=The characters you entered didn't match the word verification. Please try again.#error");
	exit();
}
else
{
	 mail($mymail, $subject, $message);
	 header("Location:contact.php?success=Thanks! We recieve your mail#success");
	 exit();
}

?>