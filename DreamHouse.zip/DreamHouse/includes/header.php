<?php
$color = mysql_query("select * from background");
$fcolor = mysql_fetch_array($color);
?>
<style>
body
{

	background-color:<?php echo $fcolor['color_code']; ?>!important;
}
</style>
<div class="navbar navbar-default navbar-fixed-top">
	<div class="container">
    	<div class="navbar-header">
        	<button type="button" class="navbar-toggle" 
            data-toggle="collapse" data-target=".navbar-collapse">
            	<span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">Dream House</a>
        </div>
        
        <div class="navbar-collapse collapse">
        	<ul class="nav navbar-nav pull-right">
            	<li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
    </div>

</div>