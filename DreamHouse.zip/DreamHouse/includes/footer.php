<!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p class="site-font">Copyright © Dream House <?php echo date('Y'); ?></p>
                </div>
            </div>
        </footer>