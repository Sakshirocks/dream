// the main js file of RK stones 

$(document).ready(function(e) {
    $('input,textarea').focus(function(e){
		$(this).css({'background-color':'rgba(255,255,255,1)'});
	});
	$('input,textarea').blur(function(e){
		$(this).css({'background-color':'rgba(255,255,255,0.6)'});
	});
	
	$('.carousel-inner .item:first-child').addClass('active');
	$('.carousel-indicators li:first-child').addClass('active');
});