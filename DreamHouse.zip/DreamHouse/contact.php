<?php
error_reporting(0);
include "includes/config.php";
$a = md5( mktime() * microtime() );
 ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dream House | Contact</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900,400italic,700italic' rel='stylesheet' type='text/css'>

    

</head>

<body>

   <?php include "includes/header.php"; ?>
   <?php 
   	$query = mysql_query("select * from contact"); 
   	$f = mysql_fetch_array($query);
   
   ?>
   

    <!-- Page Content -->
<div class="contact-page">
    <div class="container color-light top-padding">

        <!-- /.row -->

        <!-- Content Row -->
        <div class="row">
            <!-- Map Column -->
            <div class="col-md-8">
                <!-- Embedded Google Map -->
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.623423109659!2d75.82725180000001!3d26.788271299999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396dc99f213803bb%3A0xdfb9dec6d7d66948!2sCDAC+ATC+NETCOM!5e0!3m2!1sen!2sin!4v1442553258446" width="100%" height="450px" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <!-- Contact Details Column -->
            <div class="col-md-4">
                <h3 class="site-font">Contact Details</h3>
                <p class="site-font" style="max-width:150px;">
                   <?php echo $f['address']; ?>
                </p>
                <p><i class="fa fa-phone"></i> 
                    : <?php echo $f['phone']; ?></p>
                <p><i class="fa fa-envelope-o"></i> 
                    : <a href="mailto:<?php echo $f['email']; ?>"><?php echo $f['email']; ?></a>
                </p>
                <!--p><i class="fa fa-clock-o"></i> 
                    : Monday - Friday: 9:00 AM to 5:00 PM</p>
                <!--ul class="list-unstyled list-inline list-social-icons">
                    <li>
                        <a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-linkedin-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
                    </li>
                </ul-->
            </div>
        </div>
        <!-- /.row -->

        <!-- Contact Form -->
        <!-- In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
        
      
        
        <div class="row">
            <div class="col-md-8">
                <h3 class="site-font">Send us a Message</h3>
                <form name="sentMessage" id="contactForm" novalidate class="site-font" action="contact_me.php">
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Full Name:</label>
                            <input type="text" class="form-control" id="name" name="name" required data-validation-required-message="Please enter your name." placeholder="Please enter your name">
                            <p class="help-block"></p>
                          
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Phone Number:</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required data-validation-required-message="Please enter your phone number." placeholder="Please enter your phone number">
                                                       
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email" required data-validation-required-message="Please enter your email address." placeholder="Please enter your email address">
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Message:</label>
                            <textarea rows="10" cols="100" class="form-control" id="message" name="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none" placeholder="Please enter your message"></textarea>
                        </div>
                    </div>
                    <div class="form-group control-group">
                    	<div class="controls">
                   <input type="text" class="text-center" name="captcha" id="captcha" value="<?php echo substr($a,0,6); ?>" readonly/>
                        </div>
                    </div>
                    <div class="form-group control-group">
                    	<div class="controls">
                   <input type="text" name="reenter" id="reenter" placeholder="Please enter the characters you see in the box above (case sensitive)" required data-validation-required-message="Please enter the above text in the box"/>
                        </div>
                    </div>
                    <div id="success"></div>
                    <!-- For success/fail messages -->
                    <input type="submit" class="btn btn-primary" value="Send" name="submitt"/>
                 </form>
                 <p id="error" style="color:#900; font-size:18px"><?php echo $_REQUEST['error']; ?></p>
                 <p id="success" style="color:rgba(0,153,102,1); font-size:18px"><?php echo $_REQUEST['success']; ?></p>
            </div>

        </div>
        <!-- /.row -->

    </div> <!-- /.container -->
    </div><!--/contact-page-->
    
            <?php include "includes/footer.php"; ?>

    <!-- jQuery -->
    <script src="js/jquery.js" type="text/javascript"></script>

	<!--main js file of RK stones-->
    <script type="text/javascript" src="js/main.js"></script>
	
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>

    <!-- Contact Form JavaScript -->
   
   
    

</body>

</html>
