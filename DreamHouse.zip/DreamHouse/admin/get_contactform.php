<?php
include "session_check.php";
include "includes/config.php";
?>
<?php
$i=1;
$query = mysql_query("select * from contactform");
while($r = mysql_fetch_array($query))
{
?>
<tr>
	<td><?php echo $i++; ?></td>
    <td><?php echo $r['form_to']; ?></td>
    <td><?php echo $r['form_subj']; ?></td>
     <td><a href="delete.php?delform=<?php echo $r['form_id']; ?>" onClick="return confirm('Are your sure to delete this?')"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>
<?php } ?>