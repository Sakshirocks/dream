<?php include "session_check.php"; ?>
<?php include "includes/config.php"; ?>

<?php
$i=1;
$sql = mysql_query("select * from aboutteam");
while($row = mysql_fetch_array($sql))
{
?>
<tr>
	<td><?php echo $i++; ?></td>
	<td><?php echo $row['tm_name']; ?></td>
    <td><img src="../img/<?php echo $row['tm_img']; ?>" width="130px" height="120px"/> </td>
    <td><?php echo $row['tm_position']; ?></td>
    <td><a href="delete.php?delat=<?php echo $row['tm_id']; ?>" onClick="return confirm('Are your sure to delete this member?')"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>

<?php } ?>