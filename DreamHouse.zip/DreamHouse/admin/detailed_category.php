<?php include "session_check.php"; ?>
<?php
ob_start();
ob_flush();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome to Admin Panel | RK Stone</title>

<script src="//tinymce.cachefly.net/4.2/tinymce.min.js"></script>
<script>tinymce.init({selector:'textarea'});</script>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
<link href="css/bootstrap-theme.css" type="text/css" rel="stylesheet">
<link href="css/deshbord.css" type="text/css" rel="stylesheet">
<link href="css/animate.css" type="text/css" rel="stylesheet">
<link href="https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css" type="text/css" rel="stylesheet"/>


 <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>


     <?php include "header.php"; ?> 
      
     <?php include "sidebar.php"; ?>
  
  	<?php
	if(isset($_REQUEST['submit']))
	{
		$categoryList = $_REQUEST['categoryList'];
		$catdescp = htmlspecialchars($_REQUEST['cat_descp']);
		$img1 = $_FILES['img1']['name'];
		$img2 = $_FILES['img2']['name'];
		$img3 = $_FILES['img3']['name'];
		
		move_uploaded_file($_FILES['img1']['tmp_name'],'../imgcat/'.$img1);
		move_uploaded_file($_FILES['img2']['tmp_name'],'../imgcat/'.$img2);
		move_uploaded_file($_FILES['img3']['tmp_name'],'../imgcat/'.$img3);
		
		$select = mysql_query("select * from detailed_cat where dcat_name = '$categoryList' ");
		$countt = mysql_num_rows($select);
		
		if($countt > 0)
		{
			mysql_query("Update detailed_cat set
			dcat_name = '$categoryList',
			dcat_img1 = '$img1',
			dcat_img2 = '$img2',
			dcat_img3 = '$img3',
			dcat_descp = '$catdescp' WHERE dcat_name = '$categoryList' ");
		}
		else
		{
			mysql_query("Insert into detailed_cat (dcat_name, dcat_img1, dcat_img2, dcat_img3, dcat_descp) 
			VALUES
			(
			'$categoryList',
			'$img1',
			'$img2',
			'$img3',
			'$catdescp'	)");
		}
	}
		
	?>
  	 


 <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="media">
  
  <div class="media-body">
    
   <form action="" method="post" enctype="multipart/form-data">

    <table class="table table-hover">
      
      <tbody>
         <tr>
          <th  scope="row">Detail about</th>
          <td>
          	<select name="categoryList" style="width:150px; height:30px;">
            	<option value=""></option>
            	<?php
				$qq = mysql_query("select * from category");
				while($rr = mysql_fetch_array($qq))
				{
				?>
                <option value="<?php echo $rr['cat_name']; ?>"><?php echo $rr['cat_name']; ?></option>
                <?php } ?>
            </select>
          </td>
          
        </tr>
                
         <tr>
          <th  scope="row">Image 1</th>
          <td><input type="file" name="img1" id="img1" required/></td>
        </tr>
          <tr>
          <th  scope="row">Image 2</th>
          <td><input type="file" name="img2" id="img2" required/></td>
        </tr>
          <tr>
          <th  scope="row">Image 3</th>
          <td><input type="file" name="img3" id="img3" required/></td>
        </tr>
        
          <tr>
            <th scope="row">Description</th>
            <td><textarea name="cat_descp" rows="8"></textarea></td>
          </tr>
        <tr>
        <td align="right"><input type="submit" name="submit" id="submit" value="Submit" class="btn btn-info"/></td>
        
        </tr>
        
      </tbody>
    </table>
 </form>
 <div class="row">
 	<div class="col-md-12">
    	<h2>Existing Categories</h2>
    </div>
 </div>
   <table class="table table-bordered" >
      
      <thead>
         <tr>
          <th>Sno.</th>
	      <th>Category Name</th>
          <th>Image1</th>
          <th>Image2</th>
          <th>Image3</th>
          <th>Description</th>
          <th>Delete</th>
        </tr>
        
      </thead>
      
      <tbody id="categorylist">
      
      </tbody>
        
   </table>
    
  </div>
</div>
                   
                    </div>
                    
                    
                    
                     
                </div>
                
                
               
                
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->
    </div>
      



<script src="js/jquery-2.1.0.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>

<script>

$("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
     $("#menu-toggle-2").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled-2");
        $('#menu ul').hide();
    });
 
     function initMenu() {
      $('#menu ul').hide();
      $('#menu ul').children('.current').parent().show();
      //$('#menu ul:first').show();
      $('#menu li a').click(
        function() {
          var checkElement = $(this).next();
          if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            return false;
            }
          if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            $('#menu ul:visible').slideUp('normal');
            checkElement.slideDown('normal');
            return false;
            }
          }
        );
      }
    $(document).ready(function() {initMenu();});
</script>

</body>
</html>
<script>
jQuery(document).ready(function(e) {
  var userid=jQuery("#planid").val();
  
   jQuery.ajax({
	type: "POST",
	url: "get_detailed_category.php",
	data: {"userid": userid},
	success: function(data){
		//alert(data);
		//location.reload();
		jQuery("#categorylist").html(data);
		//jQuery("#planpackage").html(data);
	}
	});
	  
});

</script>






<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      ...
    </div>
  </div>
</div>



