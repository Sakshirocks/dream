<?php
include "session_check.php";
include "includes/config.php";
?>
<?php
$i=1;
$query = mysql_query("select * from contact");
while($r = mysql_fetch_array($query))
{
?>
<tr>
	<td><?php echo $i++; ?></td>
    <td><?php echo $r['address']; ?></td>
    <td><?php echo $r['phone']; ?></td>
    <td><?php echo $r['email'] ?></td>
     <td><a href="delete.php?delcont=<?php echo $r['id']; ?>" onClick="return confirm('Are your sure to delete this?')"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>
</tr>
<?php } ?>