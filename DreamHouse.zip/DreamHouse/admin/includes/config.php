<?php
$con = mysql_connect("localhost","root","");
mysql_select_db("dreamhouse",$con) or die("Could not connect to database");
?>