<?php include "includes/config.php";
ob_start();
ob_flush();
 ?>
<?php include "session_check.php"; ?>

<?php
$delhc = $_REQUEST['delhc'];
$delhs = $_REQUEST['delhs'];
$delcat = $_REQUEST['delcat'];
$deldc = $_REQUEST['deldc'];
$delac = $_REQUEST['delac'];
$delat = $_REQUEST['delat'];
$delcust = $_REQUEST['delcust'];
$delgall = $_REQUEST['delgall'];
$delcont = $_REQUEST['delcont'];
$delform = $_REQUEST['delform'];
$delcolor = $_REQUEST['delcolor'];

if($delhc)
{
	mysql_query("truncate table homecontent");
	header("location:home-content.php");
}

if($delhs)
{
	mysql_query("Delete from homeslider where hs_id = '$delhs' ");
	header("location:home-slider.php");
}

if($delcat)
{
	mysql_query("Delete from category where cat_id = '$delcat' ");
	header("location:category.php");
}

if($deldc)
{
	mysql_query("Delete from detailed_cat where dcat_id = '$deldc' ");
	header("location:detailed_category.php");
}

if($delac)
{
	mysql_query("truncate table aboutcontent");
	header("location:about-content.php");
}

if($delat)
{
	mysql_query("Delete from aboutteam where tm_id = '$delat' ");
	header("location:about-team.php");
}

if($delcust)
{
	mysql_query("Delete from customer where cust_id = '$delcust' ");
	header("location:about-customer.php");
}

if($delgall)
{
	mysql_query("Delete from image_gallery where gallery_id = '$delgall' ");
	header("location:manage-gallery.php");
}

if($delcont)
{
	mysql_query("truncate table contact");
	header("location:contact-page.php");
}

if($delform)
{
	mysql_query("truncate table contactform");
	header("location:contactform.php");
}

if($delcolor)
{
	mysql_query("truncate table background");
	header("location:change_background.php");
}
?>