<?php
include "includes/config.php";
$i=1;
$query = mysql_query("select * from image_gallery");
while($rr = mysql_fetch_array($query))
{
?>
<tr>
	<td><?php echo $i++; ?></td>
    <td><?php echo $rr['cat_name']; ?></td>
    <td><img src="../gallery-img/<?php echo $rr['gallery_feature_img'];?>" width="150px" height="100px"/></td>
    <td><a href="delete.php?delgall=<?php echo $rr['gallery_id']; ?>" onClick="return confirm('Are your sure to delete this image?')"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>

<?php } ?>
