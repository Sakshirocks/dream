<?php
include "session_check.php";
include "includes/config.php";
?>
<?php
$cpass = $_REQUEST['cpass'];
$npass = $_REQUEST['npass'];
$rnpass = $_REQUEST['rnpass'];
$query = mysql_query("select * from admin where");
if(empty($cpass) || empty($npass) || empty($rnpass))
{
	echo "0";
}
elseif($_SESSION['password'] != $cpass)
{
	echo "1";
}
elseif($npass != $rnpass)
{
	echo "2";
}
else
{
	mysql_query("update admin set password = '$npass' where username = '".$_SESSION['username']."' ");
	echo"3";
		
}

?>