<?php include "session_check.php"; ?>
<?php include "includes/config.php"; ?>
<?php
$i=1;
$query = mysql_query("Select * from category");
while($r = mysql_fetch_array($query))
{
?>
<tr>
    <td>
    	<?php echo $i++; ?>
    </td>
    <td>
    	<?php echo $r['cat_name']; ?>
    </td>
    <td>
    	<img src="../img/<?php echo $r['cat_img'];?>" width="150px" height="120px"/>
    </td>
    <td>
    	<a href="delete.php?delcat=<?php echo $r['cat_id']; ?>"><i class="fa fa-trash fa-lg"></i></a>
    </td>
</tr>
<?php } ?>