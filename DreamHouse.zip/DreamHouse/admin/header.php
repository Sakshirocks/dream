<?php include "session_check.php"; ?>
<?php include "includes/config.php"; ?>
<section class="top_bar navbar-fixed-top">
  <div class="container-fluid">
  
  <div class="row">
    <div class="col-md-12">
    <ul class="forcloapsebutton">
    <li><button type="button" class="navbar-toggle collapsed" data-toggle="collapse"  id="menu-toggle"> <i class="fa fa-th-large" aria-hidden="true"></i> </button></li>
    
    <li>
     <button class="navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2"> <i class="fa fa-th-large" aria-hidden="true"></i></button>
    
    </li>
    <li>
    <h4>Welcome <span> Admin </span></h4>
    
    </li>
    </ul>
    <ul class="pull-right">
    	<li class="logout"><a href="logout.php">Logout</a></li>
    </ul>
    </div>
    
    
  </div>
  
</div></section>