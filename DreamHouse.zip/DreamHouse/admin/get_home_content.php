<?php include "session_check.php"; ?>
<?php include "includes/config.php"; ?>

<?php
$sql = mysql_query("select * from homecontent");
while($row = mysql_fetch_array($sql))
{
?>
<tr>
	<td><?php echo $row['hc_title']; ?></td>
    <td><img src="../img/<?php echo $row['hc_feature_img']; ?>" width="130px" height="120px"/> </td>
    <td><?php echo htmlspecialchars_decode($row['hc_descp']); ?></td>
    <td><a href="delete.php?delhc=<?php echo $row['hc_id']; ?>" onClick="return confirm('Are your sure to delete this?')"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>

<?php } ?>