 <div id="wrapper">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
        
        
        <div class="row">
        
        <div class="col-sm-12">
        <ul class="sidebar-nav nav-pills nav-stacked" id="menu">
 
                <li>
                    <a href="dashboard.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-dashboard fa-stack-1x "></i></span> Dashboard</a>
                       
                <li class="active">
                    <a href="#"><span class="fa-stack fa-lg info pull-left"><i class="fa fa-home fa-stack-1x "></i></span> Home Page</a>
                    <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="home-slider.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-sliders fa-stack-1x "></i></span>Slider</a></li>
                        <li><a href="home-content.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-file fa-stack-1x "></i></span>Content</a></li>
                        <li><a href="category.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-list-alt fa-stack-1x "></i></span>Add Categories</a></li>
                        <li><a href="detailed_category.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-list-alt fa-stack-1x "></i></span>Detailed Categories</a></li>
 
                    </ul>
                </li>
               <li class="active">
                    <a href="#"><span class="fa-stack fa-lg info pull-left"><i class="fa fa-hand-pointer-o fa-stack-1x "></i></span> About Page</a>
                    <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="about-content.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-file fa-stack-1x "></i></span>Content</a></li>
                        <li><a href="about-team.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-users fa-stack-1x "></i></span>Team Members</a></li>
                        <li><a href="about-customer.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-globe fa-stack-1x "></i></span>Customers</a></li>
 
                    </ul>
                </li>
                <li class="active">
                    <a href="#"><span class="fa-stack fa-lg info pull-left"><i class="fa fa-file-photo-o fa-stack-1x "></i></span> Gallery Page</a>
                    <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="manage-gallery.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-edit fa-stack-1x "></i></span>Add/Edit Gallery</a></li>
 
                    </ul>
                </li>
                
                <li class="active">
                    <a href="#"><span class="fa-stack fa-lg info pull-left"><i class="fa fa-phone fa-stack-1x "></i></span>Contact Page</a>
                    <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="contact-page.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-edit fa-stack-1x "></i></span>Add/Edit Contact</a></li>
                        <li><a href="contactform.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-envelope-o fa-stack-1x "></i></span>Contact Form</a></li>
 
                    </ul>
                </li>
                
              
           
                   <li class="active">
                    <a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-gear fa-stack-1x "></i></span>Setting</a>
                    <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="change_background.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-edit fa-stack-1x "></i></span>Change Background Color</a></li>
                        <li><a href="change_password.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-edit fa-stack-1x "></i></span>Change Password</a></li>
                         
                    </ul>
                </li>
            </ul>
        
        </div>
        
        
        </div>
        
        
            
        </div><!-- /#sidebar-wrapper -->