<?php
include "session_check.php";
include "includes/config.php";
$i=1;
$color = $_REQUEST['color'];
$query = mysql_query("select * from background");
$c = mysql_num_rows($query);

if($c > 0)
{
	mysql_query("update background set
	color_code = '$color' where color_id = 1 ");
}
else
{

		mysql_query("insert into background(color_code)VALUES(
		'$color')");
}
echo "Color is changed successfully";
?>
