<?php include "session_check.php"; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome to Admin Panel | RK Stone</title>
<script src="//tinymce.cachefly.net/4.2/tinymce.min.js"></script>
<script>tinymce.init({selector:'textarea'});</script>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
<link href="css/bootstrap-theme.css" type="text/css" rel="stylesheet">
<link href="css/deshbord.css" type="text/css" rel="stylesheet">
<link href="css/animate.css" type="text/css" rel="stylesheet">
<link href="https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css" type="text/css" rel="stylesheet"/>


 <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>


     <?php include "header.php"; ?> 
      
     <?php include "sidebar.php"; ?>
  
  	<?php
	 
	 if(isset($_REQUEST['upload']))
	 {
		 		 
		 $featureimg = $_FILES['feature-img']['name'];
	 move_uploaded_file($_FILES['feature-img']['tmp_name'],'../gallery-img/'.$featureimg);
	 
	 $title = mysql_real_escape_string($_REQUEST['title']);
	 $description = htmlspecialchars($_REQUEST['description']);
	 
	 mysql_query("INSERT into image_gallery(cat_name, gallery_title,  gallery_feature_img, gallery_img_desc) VALUES
	 (
	 '".$_REQUEST['category']."',
	 '$title',
	 '$featureimg',
	 '$description' )");
	 
	 }
	 
	 ?>


 <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="media">
  
  <div class="media-body">
    
   <form action="" method="post" enctype="multipart/form-data">
    <table class="table table-hover">
      
      <tbody>
         <tr>
          <th  scope="row">Image title</th>
          <td><input type="text" name="title" id="title"/></td>
          
        </tr>
        
        <tr>
          <th  scope="row">Category</th>
          <td>
          <select name="category">
          		<option value="">Select Category</option>
                <?php
					$query = mysql_query("SELECT * from category");
					while($r = mysql_fetch_array($query))
					{
				 ?>
                <option value="<?php echo $r['cat_name']; ?>"><?php echo ucfirst($r['cat_name']); ?>
                </option>
                <?php } ?>
          </select> 
      &nbsp; &nbsp; &nbsp;    OR &nbsp; &nbsp; &nbsp; <a href="category.php" style="text-decoration:underline">add new category &darr;</a>
          </td>
          
        </tr>
        
                 
         <tr>
          <th  scope="row">Feature Image</th>
          <td><input type="file" name="feature-img" id="feature-img"/></td>
          
        </tr>
        
         <tr>
          <th  scope="row">Description</th>
          <td><textarea name="description" id="description" rows="5"></textarea></td>
          
        </tr>
        
        <tr>
        <td align="right"><input type="submit" name="upload" id="upload" value="Upload data"/></td>
        
        </tr>
        
      </tbody>
    </table>
 </form>
   
 <div class="row">
 	<div class="col-md-12">
    	<h2>Existing Gallery Images</h2>
    </div>
 </div>
   <table class="table table-bordered" >
      
      <thead>
         <tr>
          <th>Sno.</th>
	      <th>Category Name</th>
          <th>Feature Image</th>
          <th>Delete</th>
        </tr>
        
      </thead>
      
      <tbody id="gallerylist">
      
      </tbody>
        
   </table>
    
  </div>
</div>
                   
                    </div>
                    
                    
                    
                     
                </div>
                
                
               
                
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->
    </div>
      



<script src="js/jquery-2.1.0.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>

<script>

$("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
     $("#menu-toggle-2").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled-2");
        $('#menu ul').hide();
    });
 
     function initMenu() {
      $('#menu ul').hide();
      $('#menu ul').children('.current').parent().show();
      //$('#menu ul:first').show();
      $('#menu li a').click(
        function() {
          var checkElement = $(this).next();
          if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            return false;
            }
          if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            $('#menu ul:visible').slideUp('normal');
            checkElement.slideDown('normal');
            return false;
            }
          }
        );
      }
    $(document).ready(function() {initMenu();});
</script>

</body>
</html>
<script>
jQuery(document).ready(function(e) {
  var userid=jQuery("#planid").val();
  
   jQuery.ajax({
	type: "POST",
	url: "get_gallery.php",
	data: {"userid": userid},
	success: function(data){
		//alert(data);
		//location.reload();
		jQuery("#gallerylist").html(data);
		//jQuery("#planpackage").html(data);
	}
	});
	  
});

</script>






<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      ...
    </div>
  </div>
</div>



