<?php
session_start();
error_reporting(0);
if(isset($_SESSION['username']))
{
	header("location:dashboard.php"); 
	exit();
}
include "includes/config.php";
$color = mysql_query("select * from background");
$fcolor = mysql_fetch_array($color);
if(isset($_REQUEST['login']))
{
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];
	
	if(!empty($username) && !empty($password))
	{	
		$sql = mysql_query("select * from admin where username = '$username' and password = '$password'");
		$c = mysql_num_rows($sql);
		if($c > 0 )
		{
			$_SESSION['username'] = $username;
			$_SESSION['password'] = $password;
			header("location:dashboard.php"); 
		} 
		else
		{
			header("location:index.php?msg=Wrong Username and Password");
		}
	}
	else
	{
		header("location:index.php?msg=Please fill both fields");
	}
}

?>
<!doctype html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<style>
body
{
	background-image:url(../img/bg.png);
	background-repeat:repeat;
	background-color:<?php echo $fcolor['color_code']; ?>;
}
.loginform
{
	max-width:500px;
	margin:100px auto;
	padding:0px 20px 20px 20px;
	border:0px solid rgba(204,204,204,1);
	box-shadow:0px 0px 5px #CCCCCC;
	background-color:#ececec;
}
.loginform .col-md-12
{
	border-bottom:1px solid rgba(204,204,204,1);
	margin-bottom:20px;
	padding-top:2px;
}
.loginform .col-md-12 h2
{
	font-family:'Roboto';
	text-shadow:2px 2px 2px #999999;
	letter-spacing:0.05em;
	color:rgba(51,51,51,0.8);
}

.btn-info
{
	border-radius:0;
	padding:5px 25px 5px 25px;
	font-family:'Roboto';
	font-size:18px;
	content: '';
}
.btn-info:hover
{
	content:'&bull;';
}
</style>
</head>
<body>
<div class="container">
	<div class="row">
    
        <div class="loginform">
        <div class="col-md-12"><h2 class="text-center">Login to DreamHouse </h2></div>
            <form action="" method="post" role="form" id="form">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="uname" placeholder="Enter your username" class="form-control"/>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="pass" placeholder="Enter your password" class="form-control"/>
            </div>
            <div class="form-group">
            <input type="submit" name="login" value="Login" class="btn btn-info"/>
            </div>
            
            </form>
            <p style="color:#F00"><?php echo $_REQUEST['msg']; ?></p>
        </div><!-- loginform -->
    </div>
</div>
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>