<?php include "session_check.php"; ?>
<?php include "includes/config.php"; ?>
<?php
$i = 1;
$query = mysql_query("Select * from homeslider");
while($row = mysql_fetch_array($query))
{
?>
<tr>
	<td><?php echo $i++; ?></td>
    <td><?php echo $row['hs_alt']; ?></td>
    <td><img src="../img/<?php echo $row['hs_img']; ?>" width="100%"/></td>
    <td><a href="delete.php?delhs=<?php echo $row['hs_id']; ?>" onClick="return confirm('Are your sure to delete this slide?')"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>

<?php } ?>