<?php include "session_check.php"; ?>
<?php
include "includes/config.php";
?>
<?php
$i=1;

$query = mysql_query("Select * from detailed_cat");
while($row = mysql_fetch_array($query))
{
?>
<tr>
	<td><?php echo $i++; ?></td>
    <td><?php echo ucfirst($row['dcat_name']); ?></td>
    <td><img src="../imgcat/<?php echo $row['dcat_img1']; ?>" width="100px" height="80px"/></td>
    <td><img src="../imgcat/<?php echo $row['dcat_img2']; ?>" width="100px" height="80px"/></td>
    <td><img src="../imgcat/<?php echo $row['dcat_img3']; ?>" width="100px" height="80px"/></td>
    <td><?php echo htmlspecialchars_decode($row['dcat_descp']); ?></td>
    <td><a href="delete.php?deldc=<?php echo $row['dcat_id']; ?>"><i class="fa fa-trash fa-lg"></i></a></td>
</tr>

<?php } ?>