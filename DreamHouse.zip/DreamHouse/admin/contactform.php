<?php include "session_check.php"; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome to Admin Panel | RK Stone</title>
<script src="//tinymce.cachefly.net/4.2/tinymce.min.js"></script>
<script>tinymce.init({selector:'textarea'});</script>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
<link href="css/bootstrap-theme.css" type="text/css" rel="stylesheet">
<link href="css/deshbord.css" type="text/css" rel="stylesheet">
<link href="css/animate.css" type="text/css" rel="stylesheet">
<link href="https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css" type="text/css" rel="stylesheet"/>


 <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>


     <?php include "header.php"; ?> 
      
     <?php include "sidebar.php"; ?>
  
  	 <?php 
	 if(isset($_REQUEST['submitform']))
	 {
		 $to = $_REQUEST['emaill'];
		 $subj = $_REQUEST['subj'];
		 
		 $sql = mysql_query("select * from contactform");
		 $count = mysql_num_rows($sql);
		 if($count > 0)
		 {
			 mysql_query("update contactform set form_to = '".$to."', form_subj = '".$subj."' where form_id = 1 ");
		 }
		 else
		 {
			 mysql_query("insert into contactform(form_to,form_subj)VALUES('$to','$subj')");
		 }
	 }
	  ?>
      


 <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="media">
  
  <div class="media-body">
    
   <form action="" method="post" role="form">

    <table class="table table-hover">
      
      <tbody>
         
                
         <tr>
          <th  scope="row">To:</th>
          <td><input type="email" name="emaill" id="emaill" required/></td>
          
        </tr>
        
         
        
         <tr>
          <th  scope="row">Subject</th>
          <td><input type="text" name="subj" id="subj" required/></td>
          
        </tr>
        
              
        <tr>
        <td align="right"><input type="submit" name="submitform" id="submitform" value="Submit" class="btn btn-info"/></td>
        
        </tr>
        
      </tbody>
    </table>
 </form>
  <div class="row">
  	<div class="col-md-12">
    	<h2>Existing Contact Form Details</h2>
    </div>
  </div>
   <table class="table table-bordered">
      
      <thead>
         <tr>
          <th>Sno.</th>
          <th>To</th>
          <th>Subject</th>
		  <th>Delete</th>
        </tr>
        
      </thead>
      
      <tbody id="contactform">
      
      </tbody>
        
   </table>
    
  </div>
</div>
                   
                    </div>
                    
                    
                    
                     
                </div>
                
                
               
                
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->
    </div>
      



<script src="js/jquery-2.1.0.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>

<script>

$("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
     $("#menu-toggle-2").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled-2");
        $('#menu ul').hide();
    });
 
     function initMenu() {
      $('#menu ul').hide();
      $('#menu ul').children('.current').parent().show();
      //$('#menu ul:first').show();
      $('#menu li a').click(
        function() {
          var checkElement = $(this).next();
          if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            return false;
            }
          if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            $('#menu ul:visible').slideUp('normal');
            checkElement.slideDown('normal');
            return false;
            }
          }
        );
      }
    $(document).ready(function() {initMenu();});
</script>

</body>
</html>
<script>
jQuery(document).ready(function(e) {
  var userid=jQuery("#planid").val();
  
   jQuery.ajax({
	type: "POST",
	url: "get_contactform.php",
	data: {"userid": userid},
	success: function(data){
		//alert(data);
		//location.reload();
		jQuery("#contactform").html(data);
		//jQuery("#planpackage").html(data);
	}
	});
	  
});

</script>






<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      ...
    </div>
  </div>
</div>



