<?php include "includes/config.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dream House</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900,400italic,700italic' rel='stylesheet' type='text/css'>

    

</head>

<body>

  <?php include "includes/header.php"; ?>

	<?php
	$query = mysql_query("select * from aboutcontent");
	$row = mysql_fetch_array($query);
	?>
    <!-- Page Content -->
<div class="about-page">
    <div class="container color-light top-padding">

        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row">
            <div class="col-md-6">
            	<div class="shadow">
               	 	<img class="img-responsive" src="img/<?php echo $row['ac_fimg']; ?>"/>
                </div>
            </div>
            <div class="col-md-6">
                <h2 class="site-font"><?php echo $row['ac_title']; ?></h2>
                <p class="text-justify"><?php echo htmlspecialchars_decode($row['ac_descp']); ?></p>
               
            </div>
        </div>
        <!-- /.row -->

        <!-- Team Members -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Our Team</h2>
            </div>
           <?php
		   $sql = mysql_query("select * from aboutteam");
		   while($rr = mysql_fetch_array($sql))
		   {
		    ?>
            <div class="col-md-4 col-xs-12 text-center">
                <div class="thumbnail">
                	<div class="mem-img">
                    <img class="img-responsive" src="img/<?php echo $rr['tm_img']; ?>" alt="<?php echo $rr['tm_name']; ?>"/>
                    </div>
                    <div class="caption">
                        <h3><?php echo $rr['tm_name']; ?></h3>
                        <h3><small><?php echo $rr['tm_position']; ?></small></h>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste saepe et quisquam nesciunt maxime.</p>
                        <ul class="list-inline">
                            <li><a href="#"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>-->
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <!-- /.row -->

        <!-- Our Customers -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Our Customers</h2>
            </div>
            <?php
			$sqll = mysql_query("Select * from customer");
			while($rrr = mysql_fetch_array($sqll))
			{
			?>
            <div class="col-md-2 col-sm-4 col-xs-6">
            	<div class="client-img">
                <img class="img-responsive customer-img" src="img/<?php echo $rrr['cust_img']; ?>" alt="<?php echo $rrr['cust_name']; ?>"/>
                </div>
            </div>
            <?php } ?>
            <!--<div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="http://placehold.it/500x300" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="http://placehold.it/500x300" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="http://placehold.it/500x300" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="http://placehold.it/500x300" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="http://placehold.it/500x300" alt="">
            </div>-->
        </div>
        <!-- /.row -->

        <hr>


    </div>
    </div>
    <!-- /.container -->
    <?php include "includes/footer.php"; ?>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
