-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2016 at 04:47 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rkstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutcontent`
--

CREATE TABLE IF NOT EXISTS `aboutcontent` (
  `ac_id` int(20) NOT NULL,
  `ac_title` varchar(90) NOT NULL,
  `ac_descp` varchar(40000) NOT NULL,
  `ac_fimg` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutcontent`
--

INSERT INTO `aboutcontent` (`ac_id`, `ac_title`, `ac_descp`, `ac_fimg`) VALUES
(1, 'About RK Stone', '&lt;p class=&quot;MsoNormal&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede.&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&amp;nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&amp;nbsp;&lt;/p&gt;', 'front.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `aboutteam`
--

CREATE TABLE IF NOT EXISTS `aboutteam` (
  `tm_id` int(90) NOT NULL,
  `tm_name` varchar(1000) NOT NULL,
  `tm_img` varchar(4000) NOT NULL,
  `tm_position` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutteam`
--

INSERT INTO `aboutteam` (`tm_id`, `tm_name`, `tm_img`, `tm_position`) VALUES
(2, 'Jhon Doe2', 'member2.jpg', 'Team Leader'),
(4, 'Jhon Doe 3', 'member1.jpg', 'Contractor');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(20) NOT NULL,
  `username` varchar(90) NOT NULL,
  `password` varchar(90) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin1235');

-- --------------------------------------------------------

--
-- Table structure for table `background`
--

CREATE TABLE IF NOT EXISTS `background` (
  `color_id` int(20) NOT NULL,
  `color_code` varchar(10000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `background`
--

INSERT INTO `background` (`color_id`, `color_code`) VALUES
(1, '#af4149');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(90) NOT NULL,
  `cat_name` varchar(1000) NOT NULL,
  `cat_img` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_img`) VALUES
(1, 'Granite', 'granitetexture.jpg'),
(2, 'Limestone', 'limestone.jpg'),
(3, 'Sandstone', 'Sandstone.jpg'),
(4, 'Quartz', 'Quartz.jpg'),
(5, 'Travertine', 'Travertine.jpg'),
(6, 'Marbel', 'Marbel.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(20) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `phone` varchar(90) NOT NULL,
  `email` varchar(90) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `address`, `phone`, `email`) VALUES
(1, '5/1788 SFS mansarowar, Jaipur', '8963872777, 896666666666', 'mukul.soni0007@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contactform`
--

CREATE TABLE IF NOT EXISTS `contactform` (
  `form_id` int(90) NOT NULL,
  `form_to` varchar(1000) NOT NULL,
  `form_subj` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactform`
--

INSERT INTO `contactform` (`form_id`, `form_to`, `form_subj`) VALUES
(1, 'mukul.soni0007@gmail.com', 'Enquiry');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `cust_id` int(90) NOT NULL,
  `cust_name` varchar(1000) NOT NULL,
  `cust_img` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `cust_name`, `cust_img`) VALUES
(1, 'Customer 1', 'customer1.jpg'),
(2, 'Customer 2', 'customer2.jpg'),
(3, 'Customer 3', 'customer3.jpg'),
(4, 'Customer4', 'customer4.jpg'),
(5, 'Customer 5', 'customer5.jpg'),
(6, 'Customer 6', 'customer6.jpg'),
(7, 'Customer 7', 'customer2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `detailed_cat`
--

CREATE TABLE IF NOT EXISTS `detailed_cat` (
  `dcat_id` int(40) NOT NULL,
  `dcat_name` varchar(4000) NOT NULL,
  `dcat_img1` varchar(4000) NOT NULL,
  `dcat_img2` varchar(4000) NOT NULL,
  `dcat_img3` varchar(4000) NOT NULL,
  `dcat_descp` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detailed_cat`
--

INSERT INTO `detailed_cat` (`dcat_id`, `dcat_name`, `dcat_img1`, `dcat_img2`, `dcat_img3`, `dcat_descp`) VALUES
(4, 'Limestone', 'levy-ledge-bush-hammer.jpg', 'textures-granite-marble-limestone-florida-5.jpg', 'lime.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc ac magna. Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis. Pellentesque porttitor, velit lacinia egestas auctor, diam eros tempus arcu, nec vulputate augue magna vel risus. Cras non magna vel ante adipiscing rhoncus. Vivamus a mi. Morbi neque. Aliquam erat volutpat. Integer ultrices lobortis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin semper, ante vitae sollicitudin posuere, metus quam iaculis nibh, vitae scelerisque nunc massa eget pede. Sed velit urna, interdum vel, ultricies vel, faucibus at, quam.&lt;/p&gt;'),
(5, 'Sandstone', 'redstone.jpg', 'Agra_Red_Sandstone.jpg', 'Pink-Modak1.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;In in nunc. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Donec ullamcorper fringilla eros. Fusce in sapien eu purus dapibus commodo. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras faucibus condimentum odio. Sed ac ligula. Aliquam at eros. Etiam at ligula et tellus ullamcorper ultrices. In fermentum, lorem non cursus porttitor, diam urna accumsan lacus, sed interdum wisi nibh nec nisl. Ut tincidunt volutpat urna. Mauris eleifend nulla eget mauris. Sed cursus quam id felis. Curabitur posuere quam vel nibh. Cras dapibus dapibus nisl. Vestibulum quis dolor a felis congue vehicula. Maecenas pede purus, tristique ac, tempus eget, egestas quis, mauris. Curabitur non eros. Nullam hendrerit bibendum justo. Fusce iaculis, est quis lacinia pretium, pede metus molestie lacus, at gravida wisi ante at libero.&lt;/p&gt;'),
(6, 'Quartz', 'GRIS EXPO.jpg', 'quarts.jpg', 'quartss.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Quisque ornare placerat risus. Ut molestie magna at mi. Integer aliquet mauris et nibh. Ut mattis ligula posuere velit. Nunc sagittis. Curabitur varius fringilla nisl. Duis pretium mi euismod erat. Maecenas id augue. Nam vulputate. Duis a quam non neque lobortis malesuada. Praesent euismod. Donec nulla augue, venenatis scelerisque, dapibus a, consequat at, leo. Pellentesque libero lectus, tristique ac, consectetuer sit amet, imperdiet ut, justo. Sed aliquam odio vitae tortor. Proin hendrerit tempus arcu. In hac habitasse platea dictumst. Suspendisse potenti. Vivamus vitae massa adipiscing est lacinia sodales. Donec metus massa, mollis vel, tempus placerat, vestibulum condimentum, ligula. Nunc lacus metus, posuere eget, lacinia eu, varius quis, libero.&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;Quisque ornare placerat risus. Ut molestie magna at mi. Integer aliquet mauris et nibh. Ut mattis ligula posuere velit. Nunc sagittis. Curabitur varius fringilla nisl. Duis pretium mi euismod erat. Maecenas id augue. Nam vulputate. Duis a quam non neque lobortis malesuada. Praesent euismod. Donec nulla augue, venenatis scelerisque, dapibus a, consequat at, leo. Pellentesque libero lectus, tristique ac, consectetuer sit amet, imperdiet ut, justo. Sed aliquam odio vitae tortor. Proin hendrerit tempus arcu. In hac habitasse platea dictumst. Suspendisse potenti. Vivamus vitae massa adipiscing est lacinia sodales. Donec metus massa, mollis vel, tempus placerat, vestibulum condimentum, ligula. Nunc lacus metus, posuere eget, lacinia eu, varius quis, libero.&lt;/p&gt;'),
(7, 'Travertine', 'Travertine.jpg', 'thumby600_stone travertino 60x120.jpg', 'travertine-marble-stone-829097.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc ac magna. Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis. Pellentesque porttitor, velit lacinia egestas auctor, diam eros tempus arcu, nec vulputate augue magna vel risus. Cras non magna vel ante adipiscing rhoncus. Vivamus a mi. Morbi neque. Aliquam erat volutpat. Integer ultrices lobortis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin semper, ante vitae sollicitudin posuere, metus quam iaculis nibh, vitae scelerisque nunc massa eget pede. Sed velit urna, interdum vel, ultricies vel, faucibus at, quam.&lt;/p&gt;'),
(8, 'Marbel', 'black-and-gold-marble-texture-cool-photos-texture-backgrounds-funeral-prayer-and-memorial-cards1.jpg', 'Seamless marble texture (8).jpg', 'Seamless marble texture (12).jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc ac magna. Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis. Pellentesque porttitor, velit lacinia egestas auctor, diam eros tempus arcu, nec vulputate augue magna vel risus. Cras non magna vel ante adipiscing rhoncus. Vivamus a mi. Morbi neque. Aliquam erat volutpat. Integer ultrices lobortis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin semper, ante vitae sollicitudin posuere, metus quam iaculis nibh, vitae scelerisque nunc massa eget pede. Sed velit urna, interdum vel, ultricies vel, faucibus at, quam.&lt;/p&gt;'),
(9, 'Granite', 'blue-granite.jpg', 'black-granite-texture.jpg', 'granit_texture4055.jpg', '&lt;p class=&quot;MsoNormal&quot;&gt;Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc ac magna. Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis. Pellentesque porttitor, velit lacinia egestas auctor, diam eros tempus arcu, nec vulputate augue magna vel risus. Cras non magna vel ante adipiscing rhoncus. Vivamus a mi. Morbi neque. Aliquam erat volutpat. Integer ultrices lobortis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin semper, ante vitae sollicitudin posuere, metus quam iaculis nibh, vitae scelerisque nunc massa eget pede. Sed velit urna, interdum vel, ultricies vel, faucibus at, quam.&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `homecontent`
--

CREATE TABLE IF NOT EXISTS `homecontent` (
  `hc_id` int(20) NOT NULL,
  `hc_title` varchar(1000) NOT NULL,
  `hc_descp` text NOT NULL,
  `hc_feature_img` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homecontent`
--

INSERT INTO `homecontent` (`hc_id`, `hc_title`, `hc_descp`, `hc_feature_img`) VALUES
(1, 'Welcome to Rk stone', '&lt;p class=&quot;MsoNormal&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede.&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede.&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede.&lt;/p&gt;', 'front.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `homeslider`
--

CREATE TABLE IF NOT EXISTS `homeslider` (
  `hs_id` int(90) NOT NULL,
  `hs_alt` varchar(1000) NOT NULL,
  `hs_img` varchar(4000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homeslider`
--

INSERT INTO `homeslider` (`hs_id`, `hs_alt`, `hs_img`) VALUES
(3, 'Image 3', 'bannerimg3.jpg'),
(4, 'Image 1', 'img3.jpg'),
(5, 'Image 4', 'limestone.jpg'),
(6, '12', '2.png');

-- --------------------------------------------------------

--
-- Table structure for table `image_gallery`
--

CREATE TABLE IF NOT EXISTS `image_gallery` (
  `gallery_id` int(90) NOT NULL,
  `cat_name` varchar(1000) NOT NULL,
  `gallery_title` varchar(1000) NOT NULL,
  `gallery_feature_img` varchar(4000) NOT NULL,
  `gallery_img_desc` varchar(40000) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image_gallery`
--

INSERT INTO `image_gallery` (`gallery_id`, `cat_name`, `gallery_title`, `gallery_feature_img`, `gallery_img_desc`, `add_date`) VALUES
(7, 'Granite', 'Demo 4', 'limestone.jpg', '&lt;p&gt;this is some dummy text this is some dummy text this is some dummy text this is some dummy text this is some dummy text&lt;/p&gt;', '2015-09-19 06:00:07'),
(8, 'Travertine', 'Demo 5', 'pic1.jpg', '&lt;p&gt;this is some dummy text this is some dummy text this is some dummy text this is some dummy text this is some dummy text this is some dummy text this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:02:00'),
(9, 'Limestone', 'Demo 1', 'limestone.jpg', '&lt;p&gt;this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:03:09'),
(10, 'Sandstone', 'Demo 2', 'customer6.jpg', '&lt;p&gt;this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:03:30'),
(11, 'Quartz', 'Demo 4', 'customer5.jpg', '&lt;p&gt;this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:03:49'),
(12, 'Marbel', 'Demo 7', 'customer3.jpg', '&lt;p&gt;this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:04:06'),
(13, 'Granite', 'DEmo 8', 'granitetexture.jpg', '&lt;p&gt;this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:05:52'),
(14, 'Limestone', 'Demo 9', 'img1.jpg', '&lt;p&gt;this is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy textthis is some dummy text&lt;/p&gt;', '2015-09-19 06:06:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutcontent`
--
ALTER TABLE `aboutcontent`
  ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `aboutteam`
--
ALTER TABLE `aboutteam`
  ADD PRIMARY KEY (`tm_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `background`
--
ALTER TABLE `background`
  ADD PRIMARY KEY (`color_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactform`
--
ALTER TABLE `contactform`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `detailed_cat`
--
ALTER TABLE `detailed_cat`
  ADD PRIMARY KEY (`dcat_id`);

--
-- Indexes for table `homecontent`
--
ALTER TABLE `homecontent`
  ADD PRIMARY KEY (`hc_id`);

--
-- Indexes for table `homeslider`
--
ALTER TABLE `homeslider`
  ADD PRIMARY KEY (`hs_id`);

--
-- Indexes for table `image_gallery`
--
ALTER TABLE `image_gallery`
  ADD PRIMARY KEY (`gallery_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutcontent`
--
ALTER TABLE `aboutcontent`
  MODIFY `ac_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `aboutteam`
--
ALTER TABLE `aboutteam`
  MODIFY `tm_id` int(90) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `background`
--
ALTER TABLE `background`
  MODIFY `color_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(90) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `contactform`
--
ALTER TABLE `contactform`
  MODIFY `form_id` int(90) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cust_id` int(90) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `detailed_cat`
--
ALTER TABLE `detailed_cat`
  MODIFY `dcat_id` int(40) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `homecontent`
--
ALTER TABLE `homecontent`
  MODIFY `hc_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `homeslider`
--
ALTER TABLE `homeslider`
  MODIFY `hs_id` int(90) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `image_gallery`
--
ALTER TABLE `image_gallery`
  MODIFY `gallery_id` int(90) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
